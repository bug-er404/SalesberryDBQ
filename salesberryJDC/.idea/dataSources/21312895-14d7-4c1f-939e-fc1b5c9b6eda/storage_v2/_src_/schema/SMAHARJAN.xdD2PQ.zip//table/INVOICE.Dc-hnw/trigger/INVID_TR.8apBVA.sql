create trigger INVID_TR
    before insert
    on INVOICE
    for each row
BEGIN
    SELECT invid_seq.NEXTVAL
    INTO :new.invoiceid
    FROM dual;
END;
/

