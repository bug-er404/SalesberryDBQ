create trigger DETAILID_TR
    before insert
    on PURCHASEDETAIL
    for each row
BEGIN
    SELECT detailid_seq.NEXTVAL
    INTO :new.detailid
    FROM dual;
END;
/

