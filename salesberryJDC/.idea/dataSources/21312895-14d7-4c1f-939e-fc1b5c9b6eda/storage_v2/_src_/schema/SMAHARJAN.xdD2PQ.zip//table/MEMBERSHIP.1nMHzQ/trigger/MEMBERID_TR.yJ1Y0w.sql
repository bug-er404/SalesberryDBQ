create trigger MEMBERID_TR
    before insert
    on MEMBERSHIP
    for each row
BEGIN
    SELECT memberid_seq.NEXTVAL
    INTO :new.memberid
    FROM dual;
END;
/

