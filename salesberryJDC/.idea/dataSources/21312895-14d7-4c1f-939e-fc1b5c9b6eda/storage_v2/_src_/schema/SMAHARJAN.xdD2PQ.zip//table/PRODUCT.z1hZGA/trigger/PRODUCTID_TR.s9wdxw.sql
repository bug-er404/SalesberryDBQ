create trigger PRODUCTID_TR
    before insert
    on PRODUCT
    for each row
BEGIN
    SELECT productid_seq.NEXTVAL
    INTO :new.productid
    FROM dual;
END;
/

