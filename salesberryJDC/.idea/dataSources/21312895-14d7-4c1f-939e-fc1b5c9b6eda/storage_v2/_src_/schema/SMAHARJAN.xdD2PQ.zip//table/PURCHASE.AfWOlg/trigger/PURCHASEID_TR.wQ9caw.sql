create trigger PURCHASEID_TR
    before insert
    on PURCHASE
    for each row
BEGIN
    SELECT purchaseid_seq.NEXTVAL
    INTO :new.purchaseid
    FROM dual;
END;
/

