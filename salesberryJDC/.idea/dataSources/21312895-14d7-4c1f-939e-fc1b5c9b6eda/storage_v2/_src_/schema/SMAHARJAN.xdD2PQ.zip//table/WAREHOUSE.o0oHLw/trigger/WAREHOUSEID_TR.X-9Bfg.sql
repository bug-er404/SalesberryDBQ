create trigger WAREHOUSEID_TR
    before insert
    on WAREHOUSE
    for each row
BEGIN
    SELECT warehouseid_seq.NEXTVAL
    INTO :new.warehouseid
    FROM dual;
END;
/

