create trigger SHIPDATECK_TR
    before insert or update
    on SHIPMENT
    for each row
BEGIN
    -- Membership expiry date should be after issue date.
    if (:NEW.SHIPMENTARRIVAL < :NEW.SHIPMENTRELEASE ) then
        raise_application_error(-20532, 'Shipment arrival date cannot be before release date.');
    end if;

END;
/

