create trigger SHIPMENTID_TR
    before insert
    on SHIPMENT
    for each row
BEGIN
    SELECT shipmentid_seq.NEXTVAL
    INTO :new.shipmentid
    FROM dual;
END;
/

