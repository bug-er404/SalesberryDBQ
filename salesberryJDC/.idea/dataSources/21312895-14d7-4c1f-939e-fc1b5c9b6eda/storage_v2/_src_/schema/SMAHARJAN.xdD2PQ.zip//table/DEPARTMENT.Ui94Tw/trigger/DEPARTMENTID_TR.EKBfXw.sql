create trigger DEPARTMENTID_TR
    before insert
    on DEPARTMENT
    for each row
BEGIN
    SELECT deptid_seq.NEXTVAL
    INTO :new.departmentid
    FROM dual;
END;
/

