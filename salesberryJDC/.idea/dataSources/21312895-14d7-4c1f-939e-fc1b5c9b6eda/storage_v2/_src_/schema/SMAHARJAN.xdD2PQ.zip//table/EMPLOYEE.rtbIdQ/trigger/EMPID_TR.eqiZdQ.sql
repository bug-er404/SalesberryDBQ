create trigger EMPID_TR
    before insert
    on EMPLOYEE
    for each row
BEGIN
    SELECT empid_seq.NEXTVAL
    INTO :new.employeeid
    FROM dual;
END;
/

