create trigger SHIPTYPEID_TR
    before insert
    on SHIPMENTTYPE
    for each row
BEGIN
    SELECT shiptypeid_seq.NEXTVAL
    INTO :new.shiptypeid
    FROM dual;
END;
/

