create trigger MEMDATECK_TR
    before insert or update
    on MEMBERSHIP
    for each row
BEGIN
    -- Membership expiry date should be after issue date.
    if (:NEW.ISSUEDATE > :NEW.EXPIRYDATE ) then
        raise_application_error(-20531, 'Membership expiry date cannot be before issue date.');
    end if;

END;
/

